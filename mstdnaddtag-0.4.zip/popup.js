var Tag = ""
var Server = "";
window.onload = function() {
document.getElementById('inputserver').value = localStorage["server"];
document.getElementById('inputtag').value = localStorage["tag"];}
$(function($) {
    $('#readinputserver').click(function() {
       chrome.tabs.query( {active: true, lastFocusedWindow: true}, function (tabs) {
                var tab = tabs[0];
                //tab.urlに開いているタブのURLが入っている
                var parser = new URL(tab.url);
	       Server = parser.hostname;
	          //         alert(Server);
        localStorage["server"] = Server;
        document.getElementById('inputserver').value = Server


        });

    });
});


$("#inputtag").on("keydown", () => {
	Tag = document.getElementById('inputtag').value
	localStorage["tag"] = Tag
chrome.storage.sync.set({'tag': Tag}, function () {
});
});

