	var e = document.getElementsByClassName("autosuggest-textarea__textarea");
var e2 = document.getElementsByClassName("compose-form__buttons-wrapper");
	$("<div><input type='checkbox' id='autoaddtag' name='autoaddtag'/><label>タグ自動付加</label> <br/><label>タグ</label><input type='text' name='autoaddtagname'/></div>").insertAfter(e2[0]);
var e4 = $('[name="autoaddtagname"]');
e4.val(localStorage["autotagname"]);
var tag  = $('[name="autoaddtagname"]').val();
	
	if (localStorage["autotag"] == "on") {
var e3 = $('[name="autoaddtag"]');
	e3.prop('checked',true);
}

$(function(){
	$('textarea').keydown(function(e){
		if(e.ctrlKey){
			if(e.keyCode === 13){
$('[class="button button--block"]').click();
      		}
    	}
    });
});



$('[class="button button--block"]').click(function() {
inserttag();
});

function inserttag() {
var e = document.getElementsByClassName("autosuggest-textarea__textarea")
var e2 = $('[name="autoaddtag"]');
if (e2.prop('checked')) {
        localStorage["autotag"] = "on";
        var tag  = $('[name="autoaddtagname"]').val();
        localStorage["autotagname"] = tag;
        if (e[0].value.indexOf(tag) == -1) {
                e[0].value=e[0].value + "\n "+tag;
        }
} else {
        localStorage["autotag"] = "off";
}
};
