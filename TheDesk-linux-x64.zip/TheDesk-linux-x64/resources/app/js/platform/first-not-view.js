//jQuery読む
window.jQuery = window.$ = require('./js/common/jquery.js');
var Hammer = require('./js/common/hammer.min.js');